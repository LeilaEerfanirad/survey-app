import React from 'react'

export default function StartEndItem({ title }) {
    return (
        <div className='py-4 border rounded-md text-center border-dashed'>{title}</div>

    )
}
