import React from 'react'

export default function ShortTextAnswerModal() {
    return (
        <div>

        </div>
    )
}
